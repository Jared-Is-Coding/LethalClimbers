# Lethal Climbers

A Lethal Company mod for rock climbers! Add some of your favorite familiar objects, and shake out on some company-issued ladders.

Adds the following effects:
- Players climbing ladders feel right at home and rest easily. Stamina regeneration speed is significantly increased while climbing a ladder.

Adds the following scraps:
- Chalk Brush
- Chalk Bucket
- Climbing Hold
- Petzl Grigri
- Helmet
- Rope
- Quickdraw

Modifies the following game behaviors:
- Eyeless Dogs will now have a tasteful Adam Ondra power scream when they are aggravated

Contributors:
- 3d model textures by [AidanShipperley](https://github.com/AidanShipperley)
- Audio clips by [vulnic](https://github.com/vulnic)