# Change Logs

Here's what I've been up to...

## v1.0.4
- Update README.md to add contributors
- Add COPYING
- The Git repository for this mod is now public. I hope this can help you on your modding journey!
- Update manifest.json to point to Git repository

## v1.0.3
- Update ScanNode hitboxes for Helmet and Rope items
- Update weights of Climbing Hold, Helmet, and Grigri to be more realistic
- Climbing Hold now has voice clips to play for you
- Update Eyeless Dog screams to Adam Ondra power screams

## v1.0.2
- Update Grigri name in README.md
- Add CHANGELOG.md

## v1.0.1
- Add contributors to README.md

## v1.0.0
- Add 6 new items
  - Chalk Bucket
  - Climbing Hold
  - Petzl Grigri
  - Helmet
  - Rope
  - Quickdraw
- Add 1 new effect
  - Stamina regeneration is greatly increased while climbing ladders