# Lethal Climbers

Adds the following effects:
- Players climbing ladders feel right at home and rest easily. Stamina regeneration speed is significantly increased while climbing a ladder.

Adds the following scraps:
- Chalk Bag
- Climbing Hold
- Gri Gri
- Helmet
- Rope
- Quickdraw